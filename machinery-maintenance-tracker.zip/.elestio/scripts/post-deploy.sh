#!/bin/bash
set -e

echo "=========================================="
echo "Post-Deployment Script"
echo "Machinery Maintenance Tracker"
echo "=========================================="

# Wait for services to be ready
echo "Waiting for services to start..."
sleep 10

# Check if database is ready
echo "Checking database connection..."
max_attempts=30
attempt=0
until docker-compose -f docker-compose.elestio.yml exec -T db mysqladmin ping -h localhost -u root -p${MYSQL_ROOT_PASSWORD} --silent 2>/dev/null; do
  attempt=$((attempt + 1))
  if [ $attempt -eq $max_attempts ]; then
    echo "Error: Database failed to start after $max_attempts attempts"
    exit 1
  fi
  echo "Waiting for database... (attempt $attempt/$max_attempts)"
  sleep 2
done

echo "Database is ready!"

# Run database migrations
echo "Running database migrations..."
docker-compose -f docker-compose.elestio.yml exec -T app pnpm db:push || {
  echo "Warning: Migration failed, but continuing deployment"
}

# Check application health
echo "Checking application health..."
sleep 5
curl -f http://localhost:3000 || {
  echo "Warning: Application health check failed"
  echo "Checking logs..."
  docker-compose -f docker-compose.elestio.yml logs --tail=50 app
}

echo "=========================================="
echo "Deployment completed successfully!"
echo "=========================================="
echo ""
echo "Application URL: https://${DOMAIN}"
echo "Database: MySQL 8.0"
echo ""
echo "Next steps:"
echo "1. Access your application at the URL above"
echo "2. Sign in with your credentials"
echo "3. Start adding machines and tracking maintenance"
echo ""
echo "For support, check ELESTIO_DEPLOYMENT.md"
echo "=========================================="
